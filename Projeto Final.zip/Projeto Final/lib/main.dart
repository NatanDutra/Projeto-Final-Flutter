import 'package:datamob/firebase_options.dart';
import 'package:datamob/screens/add_menu.dart';
import 'package:datamob/screens/add_modulo.dart';
import 'package:datamob/screens/amostra.dart';
import 'package:datamob/screens/edit_menu.dart';
import 'package:datamob/screens/edit_modulo.dart';
import 'package:datamob/screens/google_maps.dart';
import 'package:datamob/screens/login.dart';
import 'package:datamob/screens/menu.dart';
import 'package:datamob/screens/modulos.dart';
import 'package:datamob/screens/pragas.dart';
import 'package:datamob/screens/upload_image.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Datamob',
      initialRoute: '/login',
      routes: {
        '/login': (context) => LoginScreen(),
        '/menu': (context) => MenuScreen(),
        '/add_menu': (context) => AddMenuScreen(),
        '/edit_menu': (context) => EditMenuScreen(),
        '/modulos': (context) => ModulosScreen(),
        '/add_modulo': (context) => AddModuloScreen(),
        '/edit_modulo': (context) => EditModuloScreen(),
        '/upload_image': (context) => UploadImageScreen(),
        '/google_maps': (context) => GoogleMapsScreen(),
        '/pragas': (context) => PragasScreen(),
        '/amostra': (context) => AmostraScreen(),
      },
    );
  }
}
