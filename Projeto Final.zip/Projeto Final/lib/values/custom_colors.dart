import 'package:flutter/material.dart';

class CustomColors {
  Color _Color1 = Color.fromARGB(255, 0, 170, 231);
  Color _Color2 = Color.fromARGB(255, 0, 113, 181);

  Color getColor1() {
    return _Color1;
  }

  Color getColor2() {
    return _Color2;
  }
}
