import 'package:flutter/material.dart';

class UploadImageScreen extends StatefulWidget {
  const UploadImageScreen({Key? key}) : super(key: key);

  @override
  _UploadImageScreenState createState() => _UploadImageScreenState();
}

class _UploadImageScreenState extends State<UploadImageScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Carregar Foto'),
      ),
      body: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Form(
                child: Column(
              children: [
                Icon(
                  Icons.image,
                  size: 50,
                ),
                Padding(padding: EdgeInsets.only(bottom: 15)),
                ElevatedButton(
                  onPressed: () {},
                  child: Text('Selecionar arquivo'),
                )
              ],
            ))
          ],
        ),
      ),
    );
  }
}
