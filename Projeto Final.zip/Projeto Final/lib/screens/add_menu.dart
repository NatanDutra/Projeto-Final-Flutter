import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AddMenuScreen extends StatefulWidget {
  const AddMenuScreen({Key? key}) : super(key: key);

  @override
  _AddMenuScreenState createState() => _AddMenuScreenState();
}

class _AddMenuScreenState extends State<AddMenuScreen> {
  TextEditingController _id = TextEditingController();
  TextEditingController _name = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Adicionar Menu'),
      ),
      body: Center(
        child: Column(
          children: [
            Form(
                child: Column(
              children: [
                TextFormField(
                  controller: _id,
                  autofocus: true,
                  decoration: InputDecoration(
                    labelText: "ID",
                    prefixIcon: Icon(Icons.vpn_key_outlined),
                  ),
                ),
                TextFormField(
                  controller: _name,
                  decoration: InputDecoration(
                      labelText: "Nome", prefixIcon: Icon(Icons.perm_identity)),
                ),
                ElevatedButton(
                  onPressed: () {
                    //Navigator.pushNamed(context, '/menu');
                    add_menu(_id.text, _name.text);
                  },
                  child: Text('Adicionar'),
                )
              ],
            ))
          ],
        ),
      ),
    );
  }

  void add_menu(id, name) {
    CollectionReference menu =
        FirebaseFirestore.instance.collection('APT_MENUS');
    menu.add({
      'cod_menu': int.parse(id),
      'nro_ordem': int.parse(id),
      'des_menu': name,
    });
    Navigator.pushReplacementNamed(
      context,
      '/menu',
    );
  }
}
