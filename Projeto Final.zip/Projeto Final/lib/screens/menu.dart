import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:datamob/classes.dart';
import 'package:flutter/material.dart';

class MenuScreen extends StatefulWidget {
  const MenuScreen({Key? key}) : super(key: key);

  @override
  _MenuScreenState createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  final Stream<QuerySnapshot> _menuStream = FirebaseFirestore.instance
      .collection('APT_MENUS')
      .orderBy('nro_ordem', descending: false)
      .snapshots(includeMetadataChanges: true);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: _menuStream,
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.hasError) {
          return Scaffold(
            body: Center(
              child: Text("Erro"),
            ),
          );
        }

        if (snapshot.connectionState == ConnectionState.waiting) {
          return Scaffold(
            body: Center(
              child: Text("Carregando"),
            ),
          );
        }
        return Scaffold(
          appBar: AppBar(
            title: Text('Menu'),
            actions: <Widget>[
              IconButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/add_menu');
                  },
                  icon: Icon(Icons.add)),
            ],
          ),
          body: Center(
            child: ListView(
              children: snapshot.data!.docs.map((DocumentSnapshot document) {
                Map<String, dynamic> data =
                    document.data()! as Map<String, dynamic>;
                return Card(
                    child: ListTile(
                  trailing: Icon(Icons.folder_open),
                  title: Text(
                      data['cod_menu'].toString() + '. ' + data['des_menu'],
                      style: TextStyle(fontSize: 20)),
                  onTap: () {
                    Navigator.pushNamed(context, '/modulos',
                        arguments:
                            PassData(data['cod_menu'], data['des_menu']));
                  },
                ));
              }).toList(),
            ),
          ),
        );
      },
    );
  }
}
