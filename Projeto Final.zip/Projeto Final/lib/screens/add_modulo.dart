import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:datamob/classes.dart';
import 'package:flutter/material.dart';

class AddModuloScreen extends StatefulWidget {
  const AddModuloScreen({Key? key}) : super(key: key);

  @override
  _AddModuloScreenState createState() => _AddModuloScreenState();
}

class _AddModuloScreenState extends State<AddModuloScreen> {
  TextEditingController _id = TextEditingController();
  TextEditingController _name = TextEditingController();
  TextEditingController _gps = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)!.settings.arguments as PassData;
    return Scaffold(
      appBar: AppBar(
        title: Text('Adicionar Módulo'),
      ),
      body: Center(
        child: Column(
          children: [
            Form(
                child: Column(
              children: [
                TextFormField(
                  controller: _id,
                  autofocus: true,
                  decoration: InputDecoration(
                    labelText: "ID",
                    prefixIcon: Icon(Icons.vpn_key_outlined),
                  ),
                ),
                TextFormField(
                  controller: _name,
                  decoration: InputDecoration(
                      labelText: "Nome", prefixIcon: Icon(Icons.perm_identity)),
                ),
                TextFormField(
                  controller: _gps,
                  decoration: InputDecoration(
                      labelText: "GPS", prefixIcon: Icon(Icons.gps_fixed)),
                ),
                ElevatedButton(
                  onPressed: () {
                    //Navigator.pushNamed(context, '/menu');
                    add_modulo(_id.text, _name.text, _gps.text, args);
                  },
                  child: Text('Adicionar'),
                )
              ],
            ))
          ],
        ),
      ),
    );
  }

  void add_modulo(id, name, gps, args) {
    CollectionReference menu =
        FirebaseFirestore.instance.collection('APT_MODULOS');
    menu.add({
      'cod_modulo': int.parse(id),
      'des_modulo': name,
      'flg_gps': gps,
    });
    Navigator.pop(context);
  }
}
