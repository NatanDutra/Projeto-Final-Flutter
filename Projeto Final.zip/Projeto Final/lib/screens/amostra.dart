import 'package:flutter/material.dart';

class AmostraScreen extends StatefulWidget {
  const AmostraScreen({Key? key}) : super(key: key);

  @override
  _AmostraScreenState createState() => _AmostraScreenState();
}

class _AmostraScreenState extends State<AmostraScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sphenophorus'),
        backgroundColor: Colors.green[700],
        actions: <Widget>[
          IconButton(onPressed: () {}, icon: Icon(Icons.edit)),
          IconButton(onPressed: () {}, icon: Icon(Icons.delete)),
        ],
      ),
      body: Center(
        child: Column(
          children: [
            Padding(padding: EdgeInsets.all(10)),
            Text('Amostra 1',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 20)),
            Form(
                child: Column(
              children: [
                TextFormField(
                  decoration: InputDecoration(
                    labelText: "Fazenda",
                    suffixIcon: Icon(Icons.search),
                  ),
                ),
                TextFormField(
                  decoration: InputDecoration(
                    labelText: "Quadra",
                    suffixIcon: Icon(Icons.search),
                  ),
                ),
                TextFormField(
                  decoration: InputDecoration(
                    labelText: "Talhão",
                    suffixIcon: Icon(Icons.search),
                  ),
                ),
              ],
            ))
          ],
        ),
      ),
    );
  }
}
