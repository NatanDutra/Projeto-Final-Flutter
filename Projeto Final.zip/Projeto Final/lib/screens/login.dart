import 'package:datamob/values/custom_colors.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController _login = TextEditingController();
  TextEditingController _senha = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 50),
        decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
              CustomColors().getColor1(),
              CustomColors().getColor2()
            ])),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(padding: EdgeInsets.only(bottom: 15)),
            Text('datamob',
                textAlign: TextAlign.center,
                style: TextStyle(fontFamily: 'Expressa', fontSize: 40)),
            Form(
                child: Column(
              children: [
                TextFormField(
                  controller: _login,
                  autofocus: true,
                  decoration: InputDecoration(
                    labelText: "Usuário",
                    prefixIcon: Icon(Icons.person),
                  ),
                ),
                TextFormField(
                  controller: _senha,
                  decoration: InputDecoration(
                    labelText: "Senha",
                    prefixIcon: Icon(Icons.vpn_key_outlined),
                  ),
                  obscureText: true,
                  enableSuggestions: false,
                  autocorrect: false,
                ),
                Padding(padding: EdgeInsets.only(bottom: 15)),
                ElevatedButton(
                  onPressed: () {
                    //Navigator.pushNamed(context, '/menu');
                    login(_login.text, _senha.text);
                  },
                  child: Text('Entrar'),
                )
              ],
            ))
          ],
        ),
      ),
    );
  }

  void login(email, senha) {
    FirebaseAuth.instance
        .signInWithEmailAndPassword(email: email, password: senha)
        .then((resultado) {
      Navigator.pushReplacementNamed(
        context,
        '/menu',
        arguments: resultado.user!.uid,
      );
    }).catchError((erro) {
      var mensagem = '';
      if (erro.code == 'user-not-found') {
        mensagem = 'ERRO: Usuário não encontrado.';
      } else if (erro.code == 'wrong-password') {
        mensagem = 'ERRO: Senha incorreta.';
      } else if (erro.code == 'invalid-email') {
        mensagem = 'ERRO: Email inválido.';
      } else {
        mensagem = 'ERRO: ${erro.message}';
      }
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$mensagem'), duration: Duration(seconds: 2)));
    });
  }
}
