import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:datamob/classes.dart';
import 'package:flutter/material.dart';

class PragasScreen extends StatefulWidget {
  const PragasScreen({Key? key}) : super(key: key);

  @override
  _PragasScreenState createState() => _PragasScreenState();
}

class _PragasScreenState extends State<PragasScreen> {
  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)!.settings.arguments as PassData;
    List _modulos_pragas = [];

    FirebaseFirestore.instance
        .collection('APT_MODULOS_PRAGAS')
        .where('cod_modulo', isEqualTo: args.id)
        .get()
        .then((QuerySnapshot querySnapshot) {
      querySnapshot.docs.forEach((doc) {
        _modulos_pragas.add(doc["cod_praga"]);
      });
    });

    final Stream<QuerySnapshot> _pragasStream = FirebaseFirestore.instance
        .collection('APT_PRAGAS')
        //.where('cod_praga', arrayContainsAny: _modulos_pragas)
        .orderBy('cod_praga', descending: false)
        .snapshots(includeMetadataChanges: true);

    (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {};

    return StreamBuilder<QuerySnapshot>(
      stream: _pragasStream,
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.hasError) {
          return Scaffold(
            body: Center(
              child: Text("Erro"),
            ),
          );
        }

        if (snapshot.connectionState == ConnectionState.waiting) {
          return Scaffold(
            body: Center(
              child: Text("Carregando"),
            ),
          );
        }
        return Scaffold(
          appBar: AppBar(
            title: Text('Pragas de ' + args.name),
            actions: <Widget>[
              IconButton(onPressed: () {}, icon: Icon(Icons.add)),
              IconButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/edit_modulo',
                        arguments: args);
                  },
                  icon: Icon(Icons.edit)),
            ],
          ),
          body: Center(
            child: ListView(
              children: snapshot.data!.docs.map((DocumentSnapshot document) {
                Map<String, dynamic> data =
                    document.data()! as Map<String, dynamic>;
                return Card(
                  child: ListTile(
                    leading: Icon(Icons.folder_open),
                    title: Text(
                        data['cod_praga'].toString() + '. ' + data['des_praga'],
                        style: TextStyle(fontSize: 20)),
                    onTap: () {
                      //Navigator.pushNamed(context, '/pragas',
                      //    arguments: modulo_id(data['cod_modulo']));
                    },
                  ),
                );
              }).toList(),
            ),
          ),
        );
      },
    );
  }
}
