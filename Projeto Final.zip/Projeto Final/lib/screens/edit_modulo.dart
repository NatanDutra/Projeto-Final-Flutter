import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:datamob/classes.dart';
import 'package:flutter/material.dart';

class EditModuloScreen extends StatefulWidget {
  const EditModuloScreen({Key? key}) : super(key: key);

  @override
  _EditModuloScreenState createState() => _EditModuloScreenState();
}

class _EditModuloScreenState extends State<EditModuloScreen> {
  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)!.settings.arguments as PassData;

    TextEditingController _id = TextEditingController(text: args.id.toString());
    TextEditingController _name = TextEditingController(text: args.name);
    return Scaffold(
      appBar: AppBar(
        title: Text('Editar Módulo'),
      ),
      body: Center(
        child: Column(
          children: [
            Form(
                child: Column(
              children: [
                TextFormField(
                  controller: _name,
                  decoration: InputDecoration(
                      labelText: "Nome", prefixIcon: Icon(Icons.perm_identity)),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        //edit_modulo(_id.text, _name.text);
                      },
                      child: Text('Editar'),
                    ),
                    Padding(padding: EdgeInsets.all(10)),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(primary: Colors.red),
                      onPressed: () {
                        //delete_modulo(_id.text, _name.text);
                      },
                      child: Text('Excluir'),
                    )
                  ],
                )
              ],
            ))
          ],
        ),
      ),
    );
  }

  void edit_modulo(id, name) {
    CollectionReference menu =
        FirebaseFirestore.instance.collection('APT_MENUS');

    FirebaseFirestore.instance
        .collection('APT_MENUS')
        .where('cod_menu', isEqualTo: int.parse(id))
        .get()
        .then((QuerySnapshot querySnapshot) {
      querySnapshot.docs.forEach((doc) async {
        await menu.doc(doc.id).update({
          'des_menu': name,
        });
        Navigator.pushReplacementNamed(
          context,
          '/menu',
        );
      });
    });
  }

  void delete_modulo(id, name) {
    CollectionReference menu =
        FirebaseFirestore.instance.collection('APT_MODULOS');

    FirebaseFirestore.instance
        .collection('APT_MODULOS')
        .where('cod_modulo', isEqualTo: int.parse(id))
        .get()
        .then((QuerySnapshot querySnapshot) {
      querySnapshot.docs.forEach((doc) async {
        await menu.doc(doc.id).delete();
        Navigator.pushReplacementNamed(
          context,
          '/modulos',
        );
      });
    });
  }
}
