import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:datamob/classes.dart';
import 'package:flutter/material.dart';

class ModulosScreen extends StatefulWidget {
  const ModulosScreen({Key? key}) : super(key: key);

  @override
  ModulosScreenState createState() => ModulosScreenState();
}

class ModulosScreenState extends State<ModulosScreen> {
  final Stream<QuerySnapshot> _modulosStream = FirebaseFirestore.instance
      .collection('APT_MODULOS')
      .orderBy('cod_modulo', descending: false)
      .snapshots(includeMetadataChanges: true);

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)!.settings.arguments as PassData;

    return StreamBuilder<QuerySnapshot>(
      stream: _modulosStream,
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.hasError) {
          return Scaffold(
            body: Center(
              child: Text("Erro"),
            ),
          );
        }

        if (snapshot.connectionState == ConnectionState.waiting) {
          return Scaffold(
            body: Center(
              child: Text("Carregando"),
            ),
          );
        }
        return Scaffold(
          appBar: AppBar(
            title: Text('Módulos de ' + args.name),
            actions: <Widget>[
              IconButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/add_modulo',
                        arguments: args);
                  },
                  icon: Icon(Icons.add)),
              IconButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/edit_menu', arguments: args);
                  },
                  icon: Icon(Icons.edit)),
            ],
          ),
          body: Center(
            child: ListView(
              children: snapshot.data!.docs.map((DocumentSnapshot document) {
                Map<String, dynamic> data =
                    document.data()! as Map<String, dynamic>;
                return Card(
                  child: ListTile(
                    leading: Icon(Icons.folder_open),
                    title: Text(
                        data['cod_modulo'].toString() +
                            '. ' +
                            data['des_modulo'],
                        style: TextStyle(fontSize: 20)),
                    onTap: () {
                      Navigator.pushNamed(context, '/pragas',
                          arguments:
                              PassData(data['cod_modulo'], data['des_modulo']));
                    },
                  ),
                );
              }).toList(),
            ),
          ),
        );
      },
    );
  }
}
