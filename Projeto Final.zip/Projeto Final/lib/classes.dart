import 'package:cloud_firestore/cloud_firestore.dart';

class PassData {
  final int id;
  final String name;
  PassData(this.id, this.name);
}

class ReturnModule {
  final int id;
  ReturnModule(this.id);

  Future get_praga() async {
    List _modulos_pragas = [];
    FirebaseFirestore db = FirebaseFirestore.instance;
    CollectionReference pragas =
        FirebaseFirestore.instance.collection('APT_MODULOS_PRAGAS');
    await pragas
        .where('cod_modulo', isEqualTo: this.id)
        .get()
        .then((QuerySnapshot querySnapshot) {
      querySnapshot.docs.forEach((doc) {
        _modulos_pragas.add(doc["cod_praga"]);
      });
    });
  }
}
