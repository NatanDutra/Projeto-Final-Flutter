package com.example.datamob

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
